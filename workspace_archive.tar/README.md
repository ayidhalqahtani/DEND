Data Modeling with Postgres

Introduction:
"A startup called Sparkify wants to analyze the data they've been collecting on songs and user activity on their new music streaming app. The analytics team is particularly interested in understanding what songs users are listening to. Currently, they don't have an easy way to query their data, which resides in a directory of JSON logs on user activity on the app, as well as a directory with JSON metadata on the songs in their app." [1]

"They'd like a data engineer to create a Postgres database with tables designed to optimize queries on song play analysis, and bring you on the project."[1]
What we did are : 
 1. we created a database schema and ETL pipline to ingest data.
 2. we applied what we learned on data modeling with postgres to build star schema  data model with different dimensions. 



you can run this project by the following commands: 
python sql_queries.py ( this file inlcudes all sql queries which used in created etl pipline )
python create_tables.py (this file is used to clean the database schema and create tables)
python etl.py  ( this file is used to read joson log files and json metadata and load these data into fact table and dimension tables)

and you can test our work by running : 
test.ipynb 

The target schema is to create one fact table which is songplays table and four dimension tables which are :
 - users table.
 - time table.
 - artists table.
 - songs table.
 
 each dimension table has specific purpose  like : songs to record all songs in music db , artists in db , songplays record all json logs file which are linked with song


References:
[1]udacity 
